module.exports = {
  content: ["./index.html", "./styles.css"],
  theme: {
    extend: {},
  },
  plugins: [],
};